<meta http-equiv="refresh" content="0; url=controller/welcome.php" />
